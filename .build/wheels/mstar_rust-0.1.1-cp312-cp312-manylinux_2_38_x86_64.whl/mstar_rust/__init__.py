from .mstar_rust import *

__doc__ = mstar_rust.__doc__
if hasattr(mstar_rust, "__all__"):
    __all__ = mstar_rust.__all__